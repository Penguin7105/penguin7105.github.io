sudo apt update && sudo apt upgrade
sudo apt install default-jdk -y
mkdir ~/paper
cd ~/paper
wget https://api.papermc.io/v2/projects/paper/versions/1.21/builds/130/downloads/paper-1.21-130.jar