sudo apt update && sudo apt upgrade
sudo apt install default-jdk -y